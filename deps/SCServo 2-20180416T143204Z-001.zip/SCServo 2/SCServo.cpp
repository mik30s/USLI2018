/*
 * SCServo.cpp
 * ���ش��ж���ӿ�
 * ����: 2017.6.6
 * ����: ̷����
 */


#include "SCServo.h"

SCServo::SCServo()
{
	IOTimeOut = 20;
	pSerial = NULL;
}

SCServo::SCServo(u8 End):SCS(End)
{
	IOTimeOut = 20;
	pSerial = NULL;
}

SCServo::SCServo(u8 End, u8 Level):SCS(End, Level)
{
	IOTimeOut = 20;
	pSerial = NULL;
}

int SCServo::readSCS(unsigned char *nDat, int nLen)
{
	int Size = 0;
	int ComData;
	unsigned long t_begin = millis();
	unsigned long t_user;
	while(1){
		ComData = pSerial->read();
		if(ComData!=-1){
			if(nDat){
				nDat[Size] = ComData;
			}
			Size++;
			t_begin = millis();
		}
		if(Size>=nLen){
			break;
		}
		t_user = millis() - t_begin;
		if(t_user>IOTimeOut){
			break;
		}
	}
	return Size;
}

int SCServo::writeSCS(unsigned char *nDat, int nLen)
{
	if(nDat==NULL){
		return 0;
	}
	return pSerial->write(nDat, nLen);
}

int SCServo::writeSCS(unsigned char bDat)
{
	return pSerial->write(&bDat, 1);
}

void SCServo::flushSCS()
{
	while(pSerial->read()!=-1);
}

int SCServo::EnableTorque(u8 ID, u8 Enable)
{
	return writeByte(ID, P_TORQUE_ENABLE, Enable);
}

int SCServo::writePos(u8 ID, u16 Position, u16 Time, u16 Speed, u8 Fun)
{
	flushSCS();
	u8 buf[6];
	Host2SCS(buf+0, buf+1, Position);
	Host2SCS(buf+2, buf+3, Time);
	Host2SCS(buf+4, buf+5, Speed);
	writeBuf(ID, P_GOAL_POSITION_L, buf, 6, Fun);
	return Ack(ID);
}

//дλ��ָ��
//���ID��Positionλ�ã�ִ��ʱ��Time��ִ���ٶ�Speed
int SCServo::WritePos(u8 ID, u16 Position, u16 Time, u16 Speed)
{
	return writePos(ID, Position, Time, Speed, INST_WRITE);
}

//�첽дλ��ָ��
//���ID��Positionλ�ã�ִ��ʱ��Time��ִ���ٶ�Speed
int SCServo::RegWritePos(u8 ID, u16 Position, u16 Time, u16 Speed)
{
	return writePos(ID, Position, Time, Speed, INST_REG_WRITE);
}

void SCServo::RegWriteAction()
{
	writeBuf(0xfe, 0, NULL, 0, INST_ACTION);
}

//дλ��ָ��
//���ID[]���飬IDN���鳤�ȣ�Positionλ�ã�ִ��ʱ��Time��ִ���ٶ�Speed
void SCServo::SyncWritePos(u8 ID[], u8 IDN, u16 Position, u16 Time, u16 Speed)
{
	u8 buf[6];
	Host2SCS(buf+0, buf+1, Position);
	Host2SCS(buf+2, buf+3, Time);
	Host2SCS(buf+4, buf+5, Speed);
	snycWrite(ID, IDN, P_GOAL_POSITION_L, buf, 6);
}

//��λ�ã���ʱ����-1
int SCServo::ReadPos(u8 ID)
{
	return readWord(ID, P_PRESENT_POSITION_L);
}

//��Ȧ����ָ��
int SCServo::WriteSpe(u8 ID, s16 Speed)
{
	if(Speed<0){
		Speed = -Speed;
		Speed |= (1<<10);
	}
	return writeWord(ID, P_GOAL_TIME_L, Speed);
}

//����ѹ����ʱ����-1
int SCServo::ReadVoltage(u8 ID)
{	
	return readByte(ID, P_PRESENT_VOLTAGE);
}

//���¶ȣ���ʱ����-1
int SCServo::ReadTemper(u8 ID)
{	
	return readByte(ID, P_PRESENT_TEMPERATURE);
}

//Pingָ����ض��ID����ʱ����-1
int SCServo::Ping(u8 ID)
{
	flushSCS();
	u8 bBuf[6];
	writeBuf(ID, 0, NULL, 0, INST_PING);
	int Size = readSCS(bBuf, 6);
	if(Size==6){
		return bBuf[2];
	}else{
		return -1;
	}
}

int SCServo::wheelMode(u8 ID)
{
	if(End){
		u8 bBuf[4];
		bBuf[0] = 0;
		bBuf[1] = 0;
		bBuf[2] = 0;
		bBuf[3] = 0;
		return genWrite(ID, P_MIN_ANGLE_LIMIT_L, bBuf, 4);
	}else{
		return writeByte(ID, P_MODE, 2);		
	}
}

int SCServo::joinMode(u8 ID, u16 minAngle, u16 maxAngle)
{
	if(End){
		u8 bBuf[4];
		Host2SCS(bBuf, bBuf+1, minAngle);
		Host2SCS(bBuf+2, bBuf+3, maxAngle);
		return genWrite(ID, P_MIN_ANGLE_LIMIT_L, bBuf, 4);
	}else{
		return writeByte(ID, P_MODE, 0);		
	}
}

//��λ�������ΪĬ��ֵ
int SCServo::Reset(u8 ID)
{
	flushSCS();
	writeBuf(ID, 0, NULL, 0, INST_RESET);
	return Ack(ID);
}

int SCServo::WriteOfs(u8 ID, s16 Ofs)
{
	if(Ofs<0){
		Ofs = -Ofs;
		Ofs |= (1<<11);
	}
	return writeWord(ID, P_OFS_L, Ofs);	
}

int SCServo::unLockEprom(u8 ID)
{
	IOTimeOut = 50;
	return writeByte(ID, P_LOCK, 0);//��EPROM���湦��
}

int SCServo::LockEprom(u8 ID)
{
	IOTimeOut = 20;
	return writeByte(ID, P_LOCK, 1);//�ر�EPROM���湦��
}